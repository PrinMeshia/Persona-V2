<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
use Framework\Persona;
use Framework\Lib\Http\Request;
use DI\ContainerBuilder;
use Modules\Main\MainModule;
use Modules\Admin\AdminModule;

define("PUBLIC_PATH", __DIR__);

require dirname(__DIR__) . "/vendor/autoload.php";
$builder = new ContainerBuilder();
$builder->addDefinitions(dirname(__DIR__) . "/persona/config/config.php");
$container = $builder->build();
include dirname(__DIR__) . "/persona/config/router.php";
$loader = new Twig_Loader_Filesystem();
$app = new Persona($container, [
    MainModule::class,
    AdminModule::class
]);

if (php_sapi_name() !== "cli") {
    $response = $app->listen(Request::createFromGlobals());
    $response->send();
}
    
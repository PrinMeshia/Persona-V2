<?php
namespace Modules\Main;

use Framework\Lib\Module\Module;
use Framework\Lib\Router\Router;
use Framework\Lib\Interfaces\RendererInterface;


class MainModule extends Module
{

    public function __construct(Router $router,RendererInterface $renderer)
    {
        parent::__construct($router,$renderer);
    }

}
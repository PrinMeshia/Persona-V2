<?php
namespace Framework\Lib\Session;

use Framework\Lib\Interfaces\SessionInterface;



class Session implements SessionInterface{

    private function EnsureStarted() {
        if(session_status() === PHP_SESSION_NONE)
            session_start();
    }
     /**
     *
     * @param string $key
     * @param mixed $default
     * @return void
     */
    public function get(string $key,$default = null){
        $this->EnsureStarted();
        if(array_key_exists($key,$_SESSION)){
            return $_SESSION[$key];
        }
        return $default;
    }
    /**
     *
     * @param string $key
     * @param mixed $value
     * @return void
     */
    public function set(string $key,$value):void{
        $this->EnsureStarted();
        $_SESSION[$key]=$value;
    }
    /**
     *
     * @param string $key
     * @return void
     */
    public function delete(string $key):void{
        $this->EnsureStarted();
        unset($_SESSION[$key]);
    }
}
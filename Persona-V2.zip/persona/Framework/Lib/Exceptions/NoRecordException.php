<?php
namespace Framework\Lib\Exceptions;

class NoRecordException extends \Exception{

}
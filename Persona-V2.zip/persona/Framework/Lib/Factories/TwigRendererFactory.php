<?php
namespace Framework\Lib\Factories;

use Framework\Lib\Router\Router;
use Psr\Container\ContainerInterface;
use Framework\lib\Render\TwigRenderer;
use Framework\lib\Render\TwigExtensions;

class TwigRendererFactory {
    public function __invoke(ContainerInterface $container):TwigRenderer
    {
        $viewPath = $container->get('view.path');
        $loader = new \Twig_Loader_Filesystem($viewPath);
        $twig = new \Twig_Environment($loader,[]);
        if($container->has('twig.extension')){
            foreach ($container->get('twig.extension') as $extension) {
                $twig->addExtension($extension);
            }
        }
       
        return new TwigRenderer($loader,$twig);
    }
}
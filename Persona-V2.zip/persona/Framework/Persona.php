<?php
namespace Framework;

use Framework\Lib\Interfaces\RequestInterface;
use Framework\Lib\Interfaces\ResponseInterface;
use Framework\Lib\Http\Response;
use Psr\Container\ContainerInterface;
use Framework\Lib\Router\Router;



class Persona
{
   /**
     * list of module
     *
     * @var array
     */
    private $components = [];
    /**
     * router
     * 
     * @var ContainerInterface
     */
    private $container;
    public function __construct(ContainerInterface $container, array $components = [])
    {
        $this->container = $container;
        foreach ($components as $component) {
            $this->components[] = $container->get($component);
        }
    }
    public function listen(RequestInterface $request):ResponseInterface{
        
        //try{
            $uri = $request->getPathInfo();
            $bodyRequest = $request->getRequest();
            if(array_key_exists('_method',$bodyRequest)&& in_array($bodyRequest['_method'],['PUT','DELETE'])){
                $request->setMethod($bodyRequest['_method']);
            }
            if(!empty($uri) && $uri[-1] === "//persona-v2//"){
                return (new Response())->redirect(substr($uri,0,-1));
            }
            
            $response = "Persona";
            $router = $this->container->get(Router::class);
            $route = $router->match($request);
            if(is_null($route)){
                return new Response(404,[],'<h1>Error</h1>');
            }
            
            $request->mergeParams($route->getParams());
            $callback = $route->getCallback();
            if(is_string($callback))
                $callback = $this->container->get($callback);
            if(is_array($callback) && is_string($callback[0])){
                $callback[0] = $this->container->get($callback[0]);
            }
            $response = call_user_func_array($callback,[$request]);
            
            if(is_string($response)){
                return new Response(200,[],$response);
            }elseif($response instanceof ResponseInterface ){
                return $response;
            }else{
                throw new \Exception('the response is available');
            }
        // }catch (\Exception $e){
        //     echo "<pre>";
        //     print_r($e);
        //     die();
            
        // }
       
    }
    /**
     *
     * @return ContainerInterface
     */
    public function getContainer():ContainerInterface{
        return $this->container;
    }
}
